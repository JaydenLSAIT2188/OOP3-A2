package test;

import org.junit.Test;
import static org.junit.Assert.*;

public class MyDLLTests {

    @Test
    public void testAddToFront() {
        MyDLL<Integer> dll = new MyDLL<>();
        dll.add(0, 1);
        dll.add(0, 2);
        assertEquals(2, dll.get(0).intValue());
        assertEquals(1, dll.get(1).intValue());
        assertEquals(2, dll.size());
    }

    @Test
    public void testAddToRear() {
        MyDLL<Integer> dll = new MyDLL<>();
        dll.add(1);
        dll.add(2);
        dll.add(3);
        assertEquals(1, dll.get(0).intValue());
        assertEquals(2, dll.get(1).intValue());
        assertEquals(3, dll.get(2).intValue());
        assertEquals(3, dll.size());
    }

    @Test
    public void testAddAtIndex() {
        MyDLL<Integer> dll = new MyDLL<>();
        dll.add(0, 1);
        dll.add(1, 2);
        dll.add(1, 3);
        assertEquals(1, dll.get(0).intValue());
        assertEquals(3, dll.get(1).intValue());
        assertEquals(2, dll.get(2).intValue());
        assertEquals(3, dll.size());
    }

    @Test
    public void testAddAll() {
        MyDLL<Integer> dll1 = new MyDLL<>();
        dll1.add(1);
        dll1.add(2);
        
        MyDLL<Integer> dll2 = new MyDLL<>();
        dll2.addAll(dll1);
        dll2.add(3);

        assertEquals(1, dll2.get(0).intValue());
        assertEquals(2, dll2.get(1).intValue());
        assertEquals(3, dll2.get(2).intValue());
        assertEquals(3, dll2.size());
    }

    @Test
    public void testRemoveByIndex() {
        MyDLL<Integer> dll = new MyDLL<>();
        dll.add(1);
        dll.add(2);
        dll.add(3);

        assertEquals(2, dll.remove(1).intValue());
        assertEquals(1, dll.get(0).intValue());
        assertEquals(3, dll.get(1).intValue());
        assertEquals(2, dll.size());
    }

    @Test
    public void testRemoveByElement() {
        MyDLL<Integer> dll = new MyDLL<>();
        dll.add(1);
        dll.add(2);
        dll.add(3);

        assertTrue(dll.remove(Integer.valueOf(2)));
        assertEquals(1, dll.get(0).intValue());
        assertEquals(3, dll.get(1).intValue());
        assertEquals(2, dll.size());
    }

    @Test
    public void testSet() {
        MyDLL<Integer> dll = new MyDLL<>();
        dll.add(1);
        dll.add(2);

        assertEquals(2, dll.set(0, 3).intValue());
        assertEquals(3, dll.get(0).intValue());
        assertEquals(2, dll.get(1).intValue());
        assertEquals(2, dll.size());
    }

    @Test
    public void testIsEmpty() {
        MyDLL<Integer> dll = new MyDLL<>();
        assertTrue(dll.isEmpty());

        dll.add(1);
        assertFalse(dll.isEmpty());
    }

    @Test
    public void testContains() {
        MyDLL<Integer> dll = new MyDLL<>();
        dll.add(1);
        dll.add(2);

        assertTrue(dll.contains(1));
        assertFalse(dll.contains(3));
    }

    @Test
    public void testToArray() {
        MyDLL<Integer> dll = new MyDLL<>();
        dll.add(1);
        dll.add(2);

        Integer[] array = new Integer[2];
        dll.toArray(array);

        assertArrayEquals(new Integer[]{1, 2}, array);
    }
}
