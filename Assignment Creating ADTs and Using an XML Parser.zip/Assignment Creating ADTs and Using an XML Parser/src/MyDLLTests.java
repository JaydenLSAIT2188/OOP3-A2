import org.junit.Test;
import static org.junit.Assert.*;

public class MyDLLTests {
    @Test
    public void testAddNode() {
        // Your test code here
    }

    @Test
    public void testRemoveNode() {
        // Your test code here
    }

    // Add more test methods for other functionalities
}
