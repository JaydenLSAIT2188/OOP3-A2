package utilities;

public interface StackADT<E> {
    
    //@param element The element to be pushed onto the stack.
 
    void push(E element);

    /**
     * @return The element at the top of the stack.
     * @throws NoSuchElementException if the stack is empty.
     */
    E pop() throws NoSuchElementException;

    /**
     * @return The element at the top of the stack.
     * @throws NoSuchElementException if the stack is empty.
     */
    E peek() throws NoSuchElementException;

    /**
     * @return true if the stack is empty, false otherwise.
     */
    boolean isEmpty();

    /**
     * @return The size of the stack.
     */
    int size();
}
