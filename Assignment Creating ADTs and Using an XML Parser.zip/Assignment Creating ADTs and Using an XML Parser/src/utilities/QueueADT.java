package utilities;

public interface QueueADT<T> {
    // @param element The element to enqueue.

    void enqueue(T element);

    //@return The front element.

    T dequeue();

    //@return The front element.

    T peek();

    //@return True if the queue is empty, false otherwise.

    boolean isEmpty();

    //@return The size of the queue.
    int size();
}

