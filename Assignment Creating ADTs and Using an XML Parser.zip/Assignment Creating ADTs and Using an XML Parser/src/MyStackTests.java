
public class MyStackTests {

}
